<?php

return array(
    '' => 'No Filter',
    'aden' => 'Aden',
    'reyes' => 'Reyes',
    'perpetua' => 'Perpetua',
    'inkwell' => 'Inkwell',
    'earlybird' => 'Earlybird',
    'toaster' => 'Toaster',
    'walden' => 'Walden',
    'hudson' => 'Hudson',
    'gingham' => 'Gingham',
    'mayfair' => 'Mayfair',
    'lofi' => 'Lo-fi',
    'xpro2' => 'X-Pro 2',
    '_1977' => '1977',
    'brooklyn' => 'Brooklyn',
);
