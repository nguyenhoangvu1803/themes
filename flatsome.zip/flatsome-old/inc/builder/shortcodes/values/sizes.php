<?php

return array(
    'xxsmall' => 'XX-Small',
    'xsmall' => 'X-Small',
    'smaller' => 'Smaller',
    'small' => 'Small',
    '' => 'Normal',
    'large' => 'Large',
    'larger' => 'Larger',
    'xlarge' => 'X-Large',
    'xxlarge' => 'XX-Large',
);
