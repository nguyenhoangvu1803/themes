<?php

return array(
  'simple' => 'Simple',
  'reveal' => 'Reveal',
  'circle' => 'Circle'
)

?>