<?php

add_action( 'ux_builder_setup', function () {
  require_once __DIR__ . '/_root.php';
  require_once __DIR__ . '/gallery.php';
} );
