<?php 
/* 
  
    $type_nav = get_theme_mod('type_nav', array('font-family'=> 'Lato','variant' => '700'));
    $type_texts = get_theme_mod('type_texts', array('font-family'=> 'Lato','variant' => '400'));
    $type_headings = get_theme_mod('type_headings',array('font-family'=> 'Lato','variant' => '700'));
    $type_alt = get_theme_mod('type_alt', array('font-family'=> 'Dancing Script')); */

return array("preset_home" => 'Sport Shop','type_headings' => array('font-family'=> 'Montserrat'), 'type_texts' => array('font-family'=> 'Lato'), 'type_nav' => array('font-family'=> 'Montserrat','variant' => '700'),"topbar_show" => "0","header_width" => "full-width","header_height" => "86","header_color" => "dark","header_bg" => "rgba(10,10,10,0.9)","cart_icon" => "cart","footer_1_color" => "dark","footer_1_bg_color" => "#222","footer_2_bg_color" => "#111","color_primary" => "#008cb2","color_secondary" => "#4ad8ff","footer_bottom_align" => "center", "footer_bottom_color" => '#000');